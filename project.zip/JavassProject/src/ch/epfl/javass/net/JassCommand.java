package ch.epfl.javass.net;
public enum JassCommand { PLRS, TRMP, HAND, TRCK, CARD, SCOR, WINR, RSKR, NAME, RVNG; }
